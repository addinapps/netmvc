﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Optimization;
using System.Web.Routing;

namespace AADB2C.WebClientMvc
{
    using System.Security.Claims;
    public class MvcApplication : System.Web.HttpApplication
    {
        protected void Application_Start()
        {
            AreaRegistration.RegisterAllAreas();
            FilterConfig.RegisterGlobalFilters(GlobalFilters.Filters);
            RouteConfig.RegisterRoutes(RouteTable.Routes);
            BundleConfig.RegisterBundles(BundleTable.Bundles);
        }

        protected void Application_PostAuthenticateRequest(Object sender, EventArgs e)
        {
            ClaimsIdentity id = ((ClaimsIdentity)User.Identity);
            Claim claim = id.FindFirst(ClaimTypes.Email);
            if (claim != null)
            {
                string email = claim.Value;
                id.AddClaim(new Claim(ClaimTypes.Name, email));
            }
        }
    }
}
